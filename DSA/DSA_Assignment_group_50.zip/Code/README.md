### Project no.5

---


- Group `50`
 
#### CS F211 DSA 2022-23 Sem 2  
#### BITS Pilani Pilani Campus  

```c

Instructions to execute code:

1. Keep the data/testcases file in the same folder as DSA_Assignment_group_50.c file. 

2. Pass the filename of testcases file with extension as command-line argument.

3. Open terminal and navigate to the folder where DSA_assignment_group_50.c file is kept.

4. Enter the following command without "" and press enter.

5. For unix-based systems :

"gcc DSA_assignment_group_50.c -o DSA_assignment_group_50 && ./DSA_assignment_group_50 <data_filename.extension>

6. For windows systems :

"gcc DSA_assignment_group_50.c -o DSA_assignment_group_50.exe"
".\DSA_assignment_group_50.exe <data_filename.extension>"

```
