Comparator is used to compare two objects of different classes while comparable is used for comparison of two same classes object.

