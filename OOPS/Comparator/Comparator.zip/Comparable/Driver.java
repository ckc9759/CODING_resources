import java.util.*;

public class Driver {
    public static void main(String args[]) {
        List<Member> member = new ArrayList<Member>();
        member.add(new Member("mikael", 182));
        member.add(new Member("matti", 187));
        member.add(new Member("ada", 184));
        // Printing the initial list of members
        member.stream().forEach(m -> System.out.println(m));
        System.out.println();
        // sorting a list with the sort-method of the Collections class
        Collections.sort(member);
        // Printing the list after sorting
        member.stream().forEach(m -> System.out.println(m));
    }
}
/**
 * What happens if you remove <Member> from the line public class Member
 * implements Comparable<Member>?
 */