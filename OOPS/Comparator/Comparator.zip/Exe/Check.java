package Exe;
import java.util.*;
import java.util.ArrayList;
import java.util.Comparator;

public class Check implements Comparator<Delivery>{
    public int compare(Delivery a, Delivery b){
        if(a.profit!=b.profit){
            return b.profit-a.profit;
        }
        else{
            return a.address.compareTo(b.address);
        }
    }
}

class Main{
    public static void main(String[] args){
        ArrayList<Delivery> delivery = new ArrayList<Delivery>();
        Address a = new Address("lalala", "zzzzzz", "Z", "Bihar", 12343);
        Address b = new Address("blalala", "azzzzz", "P", "Aindihar", 11234);
        Address c = new Address("clalala", "mzzzzz", "Ratna", "miBihar", 1254);
        Address d = new Address("clalala", "qzzzzz", "PSatna", "mittBihar", 1234);
        Address e = new Address("dlalala", "azzzzz", "Satna", "qBihar", 1244);
        delivery.add(new Delivery(a, 500));
        delivery.add(new Delivery(b, 500));
        delivery.add(new Delivery(c, 100));
        delivery.add(new Delivery(d, 700));
        delivery.add(new Delivery(e, 300));
        System.out.println("Unsorted");
        for(int i=0;i<delivery.size();i++){
            System.out.println(delivery.get(i));
        }
        Collections.sort(delivery, new Check());
        System.out.println("\nSorted");
        for(int i=0;i<delivery.size();i++){
            System.out.println(delivery.get(i));
        }
    }
}
