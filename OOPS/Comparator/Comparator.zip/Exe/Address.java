package Exe;

public class Address implements Comparable<Address> {
    public String line1;
    public String line2;
    public String city;
    public String state;
    public int pincode;

    public Address(String line1, String line2, String city, String state,
            int pincode) {
        this.line1 = line1;
        this.line2 = line2;
        this.city = city;
        this.state = state;
        this.pincode = pincode;
    }

    @Override
    public int compareTo(Address address) {
        if (this.state.equals(address.state)) {
            if (this.city.equals(address.city)) {
                return this.pincode - address.pincode;
            }
            return this.city.compareTo(address.city);
        }
        return this.state.compareTo(address.state);
    }
}