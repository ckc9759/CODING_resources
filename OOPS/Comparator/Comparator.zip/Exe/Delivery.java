package Exe;

public class Delivery {
    Address address;
    int profit;

    public Delivery(Address address, int profit) {
        this.address = address;
        this.profit = profit;
    }

    public String toString(){
        return this.address.state+" "+this.address.city+" "+this.profit;
    }
}
