import java.util.*;

public class Driver1 {
    public static void main(String[] args){
        List<Student> student = new ArrayList<Student>();
        student.add(new Student("Chaitanya", "10th", 90));
        student.add(new Student("Ananya", "07th", 90));
        student.add(new Student("Vinu", "13th", 90));
        student.add(new Student("Pari", "12th", 90));
        student.stream().forEach(m->System.out.println(m));
        System.out.println(" ");
        Collections.sort(student);
        student.stream().forEach(m->System.out.println(m));
    }
}
