import java.util.*;

class Wing {
    String bhawan;
    int count;
    int id;

    Wing(String bhawan, int count, int id) {
        this.bhawan = bhawan;
        this.count = count;
        this.id = id;
    }

    public String toString() {
        return this.bhawan + " " + this.count + " " + this.id;
    }
}

class SortByWing implements Comparator<Wing> {

    public int compare(Wing a, Wing b) {
        return a.bhawan.compareToIgnoreCase(b.bhawan);
    }
}

class SortByCount implements Comparator<Wing> {
    public int compare(Wing a, Wing b) {
        if (a.count == b.count) {
            return a.id - b.id;
        }
        return a.count - b.count;
    }
}

class Main {
    public static void main(String[] args) {
        ArrayList<Wing> wingies = new ArrayList<Wing>();
        wingies.add(new Wing("Budh", 12, 1000));
        wingies.add(new Wing("Shankar", 7, 900));
        wingies.add(new Wing("Ram", 18, 3000));
        wingies.add(new Wing("Gandhi", 18, 1500));
        System.out.println("Unsorted");
        for (int i = 0; i < wingies.size(); i++) {
            System.out.println(wingies.get(i));
        }
        Collections.sort(wingies, new SortByWing());
        System.out.println("\nSorted by Wing");
        for (int i = 0; i < wingies.size(); i++) {
            System.out.println(wingies.get(i));
        }
        Collections.sort(wingies, new SortByCount());
        System.out.println("\nSorted by Count");
        for (int i = 0; i < wingies.size(); i++) {
            System.out.println(wingies.get(i));
        }
    }
}
