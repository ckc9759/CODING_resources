public class Student implements Comparable<Student> {
    private String name;
    private String standard;
    private int marks;

    public Student(String name, String standard, int marks) {
        this.name = name;
        this.standard = standard;
        this.marks = marks;
    }

    public int getMarks() {
        return this.marks;
    }

    public int compareTo(Student student) {
        if(this.marks==student.getMarks()){
            return this.standard.compareTo(student.getStandard());
        }
        return this.marks - student.getMarks();
    }

    public String getName() {
        return this.name;
    }

    public String getStandard() {
        return this.standard;
    }

    public String toString() {
        return this.name + " : " + this.marks;
    }
}
