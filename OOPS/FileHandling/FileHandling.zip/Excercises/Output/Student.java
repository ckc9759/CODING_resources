package Excercises.Output;

import java.io.PrintWriter;
import java.io.FileWriter;

public class Student {
    String name;
    int year, age;

    Student(String name, int year, int age) {
        this.name = name;
        this.year = year;
        this.age = age;
    }
}

class PrintWriterExample {
    public static void main(String[] args) throws Exception {
        PrintWriter pw = new PrintWriter(System.out); // line1
        pw.write("Hey JavaBeans!\n");
        pw.flush();
        Student s1 = new Student("Teja", 2020, 22);
        pw.close();
        PrintWriter pw1 = null;
        pw1 = new PrintWriter(new FileWriter("Excercises/Output/output1.txt", true)); // line2
        pw1.write("BITS Pilani Students info \n");
        // pw1.flush();
        // check the file contents
        Student s2 = new Student("Harshith", 2020, 22);
        pw1.write("Student1 Details:\n");
        pw1.print("Name: " + s1.name + "\n");
        pw1.print("Year: " + s1.year + "\n");
        pw1.write("Age: " + s1.age + "\n");
        pw1.write("-------------------\n");
        // pw1.print(s1);
        pw1.write("Student2 Details:\n");
        pw1.write("Name: " + s2.name + "\n");
        pw1.write("Year: " + s2.year + "\n");
        pw1.write("Age: " + s2.age + "\n");
        pw1.write("-------------------");
        pw1.flush();
        pw1.close();
        /*
         * After running the above program!
         * The contents of the output file will be of the following form:
         * BITS Pilani Students info
         * Teja,2020,22
         * Harshith,2020,22
         * Questions:
         * 1) What is the importance of a boolean argument "true" in creating
         * an instance of the FileWriter in line2? Try to remove it and
         * Run, What changes do you observe in the file contents?
         * 2) Replace the "write" method in the line3,4 with the "print" method.
         * What changes do you see?
         * 3) Comment out line5, see what it is doing or adding to the
         * File contents?
         * 4) After answering the 2nd and 3rd questions, as of now how many
         * different signatures are there for the "print" method?
         */
    }
}
