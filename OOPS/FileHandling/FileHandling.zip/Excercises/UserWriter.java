package Excercises;
// import java.util.*;
import java.io.*;
public class UserWriter {
    public static void main(String[] args) throws IOException {
        FileReader input = null;
        FileWriter output = null;
        try{
            input = new FileReader("Excercises/user.txt");
            output = new FileWriter("Excercises/out.txt");
            int c;
            while((c=input.read())!=-1){
                output.write(c);
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        finally{
            input.close();
            output.close();
        }
    }
}
