package Excercises;

import java.util.Scanner;
import java.io.*;

public class UserReader {
    public static void main(String[] args)throws IOException {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter user data: ");
        String data = in.nextLine();
        BufferedOutputStream ckc = null;
        try{
            FileOutputStream output = new FileOutputStream("Excercises/user.txt");
            ckc = new BufferedOutputStream(output);
            ckc.write(data.getBytes());
        }
        catch(Exception e){
            System.out.println(e);
        }
        finally{
            ckc.close();
            in.close();
        }
    }
}
