package Excercises.Seq;

import java.util.*;
import java.io.SequenceInputStream;
import java.io.FileInputStream;
// import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.FileReader;

public class sequence {
    public static void main(String args[]) throws Exception {
        FileInputStream input1 = new FileInputStream("Excercises/Seq/studname.txt");
        FileInputStream input2 = new FileInputStream("Excercises/Seq/studId.txt");
        Scanner sc = new Scanner(new FileReader("Excercises/Seq/ckc.txt"));
        PrintWriter pw = new PrintWriter("Excercises/Seq/output.txt");
        String s="";
        String newline = null;
        Scanner sc1=null;
        while(sc.hasNextLine()){
            newline=sc.nextLine();
            sc1 = new Scanner(newline);
            sc1.useDelimiter(" ");
            s+="Hello "+sc1.next()+"\n";
            s+="ID : "+sc1.nextInt()+"\n";
            sc1.close();
            pw.write(s);
            pw.flush();
            s="";
        }
        sc.close();
        pw.close();
        // line1
        SequenceInputStream inst = new SequenceInputStream(input1, input2);
        int j;
        while ((j = inst.read()) != -1) {
            System.out.print((char) j);
        }
        inst.close();
        input1.close();
        input2.close();
    }
}
/*
 * Let's say the contents in studname.txt are:
 * Geetika
 * Teja
 * Arjun
 * In studId.txt are:
 * 2020H1030112P
 * 2020H1030113P
 * 2020H1030114P
 * The output on the console is:
 * Geetika
 * Teja
 * Arjun
 * 2020H1030112P
 * 2020H1030113P
 * 2020H1030114P
 * Sneak peek:
 * We can also read inputs from more than two input streams using
 * SequenceInputStream, but using Enumerations, Look into this aspect by
 * yourselves to learn more. By default, we can hardcode only two input
 * streams using the available constructor of the class.
 */
