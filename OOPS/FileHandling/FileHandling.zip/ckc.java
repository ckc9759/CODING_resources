import java.io.*;

public class ckc {
    public static void main(String[] args) throws IOException {
        // FileInputStream fileInputStream = new FileInputStream(new File("ckc.txt"));
        FileInputStream abc = new FileInputStream("input.txt");// enter appropriate file location
        BufferedInputStream def = new BufferedInputStream(abc);
        // BufferedInputStream input = new BufferedInputStream(fileInputStream);
        try {
            char c = (char) def.read();
            System.out.println("Read:' " + c + " 'from the file");
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            def.close();
        }
    }
}