package Streams;

import java.io.*;

public class Byte1 {
    public static void main(String args[]) throws Exception {
        FileOutputStream fout1 = new FileOutputStream("Streams/output3.txt");
        fout1.write("Hey! I'm File1\n".getBytes());
        FileOutputStream fout2 = new FileOutputStream("Streams/output4.txt");
        fout2.write("Hello! I'm File2\n".getBytes());
        ByteArrayOutputStream bout = new ByteArrayOutputStream();
        String s = "Hi this is annoucement";
        byte buf[] = s.getBytes();
        bout.write(buf); // line1
        bout.writeTo(fout1); // line2
        bout.writeTo(fout2);
        bout.flush();
        bout.close();
        fout1.close();
        fout2.close();
    }
}
