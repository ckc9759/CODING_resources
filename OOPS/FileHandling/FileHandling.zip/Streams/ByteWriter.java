package Streams;

import java.io.*;

public class ByteWriter {
    public static void main(String[] args) throws IOException {
        String data = "We are learning to use byte streams.";
        String data2="Hello, we are learning";
        BufferedOutputStream ckc = null;
        BufferedOutputStream ckc12 = null;
        try {
            // If a file does not exist at the specified location,
            // a new file would be automatically created
            // else, the content of the existing file would beoverridden
            FileOutputStream fileOutputStream = new FileOutputStream(new File("Streams/ckc.txt"));
            FileOutputStream ckc2 = new FileOutputStream(new File("Streams/ckc2.txt"));
            ckc = new BufferedOutputStream(fileOutputStream);
            ckc12 = new BufferedOutputStream(ckc2);
            ckc.write(data.getBytes());
            ckc12.write(data2.getBytes());
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            ckc.close();
            ckc12.close();
        }
    }
}
