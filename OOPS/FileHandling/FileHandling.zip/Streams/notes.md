```
Hello
```

If the data flow into the program, then it is called instream else outstream. 

Input stream : BufferedInputStream, FileInputStream, DataInputStream, ByteArrayInputStream
Output stream : BufferedOutputStream, FileOutputStream, DataOutputStream, ByteArrayOututStream

