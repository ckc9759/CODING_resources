package Streams;

import java.io.*;

public class Byte2 {
    public static void main(String[] args)throws IOException{
        FileOutputStream a1 = new FileOutputStream("Streams/ckc1.txt");
        a1.write("Hello i am ckc\n".getBytes());
        FileOutputStream a2 = new FileOutputStream("Streams/baj.txt");
        a2.write("Hii i am baj\n".getBytes());
        ByteArrayOutputStream bt = new ByteArrayOutputStream();
        String baj = "Heyya";
        byte buff[]=baj.getBytes();
        bt.write(buff);
        bt.writeTo(a1);
        bt.writeTo(a2);
        bt.flush();
        bt.close();
        a1.close();
        a2.close();
    }
}
