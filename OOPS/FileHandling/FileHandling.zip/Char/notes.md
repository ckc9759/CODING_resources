Unicode conventions

Character streams -> Allows us to read and write 16-bit Unicode characters

Character streams are often considered "wrappers" for byte streams.