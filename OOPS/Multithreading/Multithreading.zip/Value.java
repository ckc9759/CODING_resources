// import java.util.Scanner;

class A {
    public void printName() {
        System.out.println("Value A");
    }
}

class B extends A {
    public void printName() {
        System.out.println("Value B");
    }
}

public class Value {
    public static void main(String[] args) {
        A b = new B();
        b.printName();
        int[] index = new int[5];
        System.out.println(index instanceof Object);
    }
}
