// import java.io.IOException;

// import java.util.*;

public class Bees {

    synchronized void go() throws InterruptedException {
        Thread t1 = new Thread();
        t1.start();
        System.out.println("1 ");
        t1.wait(5000);
        System.out.println("2 ");
    }

    public static void main(String[] args) {
        try{
            new Bees().go();
    }
        catch(Exception e){
            System.out.print("in main");
        }
    }

}
