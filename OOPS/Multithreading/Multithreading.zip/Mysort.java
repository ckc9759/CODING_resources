import java.util.*;

public class Mysort implements Comparator<Integer> {
    public int compare(Integer x, Integer y) {
        return y.compareTo(x);
    }
}
enum Month {JAN, FEB, MAR};
class Main2 {
    public static void main(String[] args) {
        Integer[] primes = { 2, 7, 5, 3 };
        Mysort ms = new Mysort();
        Arrays.sort(primes, ms);
        for(Integer ps : primes){
            System.out.print(ps+" ");
        }
        System.out.println();
        Month m1 = Month.JAN;
        Month m2 = Month.JAN;
        Month m3 = Month.FEB;
        System.out.println(m1==m2);
        System.out.println(m1.equals(m2));
        System.out.println(m1==m3);
        System.out.println(m1.equals(m3));
    }
}