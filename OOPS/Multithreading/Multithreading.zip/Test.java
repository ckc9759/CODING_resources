// import java.net.SocketImpl;
import java.util.*;

class Test {
    public static void main(String args[]) {
        ArrayList<Integer> al1 = new ArrayList<Integer>();
        al1.add(20);
        al1.add(9);

        ArrayList<Integer> al2 = new ArrayList<Integer>();
        al2.add(22);
        al2.add(53);

        al1.addAll(al2);
        Collections.sort(al1);
        System.out.println(al1);
        System.out.println(al1.get(3));

        HashSet<Integer> set = new HashSet<Integer>();
        set.add(12);
        set.add(63);
        set.add(34);
        set.add(45);
        set.add(12);

        Iterator<Integer> iterator = set.iterator();
        System.out.print("Set data: ");
        while (iterator.hasNext()) {
            System.out.print(iterator.next() + " ");
        }
        System.out.println();
        ArrayList<Integer> al = new ArrayList<Integer>();
        al.add(20);
        al.add(9);
        al.add(22);
        al.add(53);
        Collections.sort(al);
        ListIterator<Integer> itr = al.listIterator();
        System.out.println("Forward Traversal");
        while (itr.hasNext()) {
            System.out.println(itr.next());
        }
        System.out.println("Backward Traversal");
        while (itr.hasPrevious()) {
            System.out.println(itr.previous());
        }

    }
}