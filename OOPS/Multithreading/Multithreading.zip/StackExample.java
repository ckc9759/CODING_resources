class StackExample {
    public static void check(int i) {
        if (i == 0)
            return;
        else {
            check(i++);
        }
    }
}

class Main {
    public static void main(String[] args) {
        StackExample.check(5);
    }
}