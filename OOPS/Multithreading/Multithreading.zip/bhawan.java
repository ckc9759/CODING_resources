import java.util.*;

class bhawan implements Comparable<bhawan>{
    int room;
    String id;
    int wingSize;
    bhawan(int room, String id,int wingSize){
        this.room=room;
        this.id=id;
        this.wingSize=wingSize;
    }
    public int compareTo(bhawan abc){
        if(room==abc.room){
            return 0;
        }
        else if(room>abc.room){
            return 1;
        }
        else return -1;
    }
    public String toString(){
        return " room : "+room+" ID : "+id+"\n";
    }
}

class Test2{
    public static void main(String[] args){
        ArrayList<bhawan> shankar = new ArrayList<bhawan>();
        shankar.add(new bhawan(3153,"1869", 6));
        shankar.add(new bhawan(3158,"1880", 5));
        shankar.add(new bhawan(3150,"1839", 5));
        shankar.add(new bhawan(3156,"1889", 7));
        shankar.add(new bhawan(3151,"1819", 4));
        Collections.sort(shankar);
        for(int i=0;i<shankar.size();i++){
            System.out.print(shankar.get(i));
        }
    }
}
