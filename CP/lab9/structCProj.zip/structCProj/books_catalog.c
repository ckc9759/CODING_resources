#include "books_catalog.h"

void addBookToCatalog(BOOK book1)
{
    // implement this function as per specification in books_catalog.h

    return;
    
}

void printBookCatalog()
{
    // implement this function as per specification in books_catalog.h

    return;
}

void sortBookCatalogOnID()
{
    // implement this function as per specification in books_catalog.h

    return;
}