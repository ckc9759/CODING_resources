#include "book_def.h"

BOOK newBook(int ID, SHELF shelfNum, float price)
{
    // implement this function as per specification in books_def.h
}

void printBook(BOOK book1)
{
   // implement this function as per specification in books_def.h
   return;
}