#!/usr/bin/env python3

from Crypto.Util.number import *
from key_mtp_p2 import key_gen
import string
import random
import sys

# Finding the random key
length = int(input("Enter the length of random key : "))
key = key_gen(length)
# key2=key.decode('shift-jis')
# rand_key2=bytes_to_long(key_gen(length))
print(f"Generated Key in bytes : {key}")
# print(f"Generated Key in strings : {key2}")
# print(type(key))


"""

    Encrypt the given message using the multi-time pad cipher
    
"""

# Encryption code


def MTP_encrypt(message, key):
    ciphertext = []
    for i in range(len(message)):
        ciphertext.append(message[i] ^ key[i % len(key)])
    return bytes(ciphertext)


plaintext = input("Enter the text to encrypt : ")
plaintext = plaintext.encode()
# print(type(plaintext))

# Converting the plaintext to bytes from string
# plaintext=bytes(plaintext,'utf-8')

ciphertext = MTP_encrypt(plaintext, key)
# ciphertext2=ciphertext.decode('utf-8')

print("\n\n")
print("Encrypting....")
print(f"Ciphertext in bytes: {ciphertext}")
# print(f"Ciphertext in strings: {ciphertext2}")
