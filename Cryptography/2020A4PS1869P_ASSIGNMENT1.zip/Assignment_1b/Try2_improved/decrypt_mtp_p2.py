#!/usr/bin/env python3

from Crypto.Util.number import *
from key_mtp_p2 import key_gen
import string
import random
import sys
from base64 import b64decode, b64encode

# Function to find the xor of two lists and return the bytes


def xor_list(list1, list2):
    # XORs two byte lists of the same length.
    list3 = [chr(ord(b1) ^ ord(b2)) for b1, b2 in zip(list1, list2)]
    return "".join(list3)


"""

    Decrypt the given ciphertext using the multi-time pad cipher
    
"""

# Decryption code


def MTP_decrypt(ciphertext, key):
    message = []
    for i in range(len(ciphertext)):
        message.append(ciphertext[i] ^ key[i % len(key)])
    return bytes(message)


ciphertext = input("Enter the text to decrypt : ")
byte_c = b64decode(ciphertext)  # byte string input

# byte_c=ciphertext.encode('utf-8')

# Converting the ciphertext to bytes from string
# ciphertext=bytes(ciphertext,'utf-8')

key = input("Enter the key for decrypting : ")
byte_key = b64decode(key)  # byte string input
print(len(key))
print(len(byte_key))

# byte_key=key.encode('utf-8')
# key=bytes(key,'utf-8')

plaintext = MTP_decrypt(byte_c, byte_key)
# plaintext2=MTP_decrypt(ciphertext,key)

print("\n\n")
print("Decrypting....")
print(f"Plaintext : {plaintext}")
# print(f"Plaintext : {plaintext2}")
