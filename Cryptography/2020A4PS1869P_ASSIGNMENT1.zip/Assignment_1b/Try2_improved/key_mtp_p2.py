import os
import sys
import random
# from Crypto.Util.number import *
# import os
# import sys

# def key_gen(length):
# return os.urandom(length)

"""
if len(sys.argv) == 0:
   print("Please provide the length as argument")
else:
   print("Random key : ",key_gen(int(sys.argv[1])))
"""

# Generates a random key but returns a byte string with a diffn length.
# Should use a random string key directly (ASCII)

# --- Approach 2

# -----------------------------

"""

Generate a random key of given length

"""


def key_gen(length):
    key = []
    for i in range(length):
        key.append(random.randint(0, 255))
    return bytes(key)

# -----------------------------
