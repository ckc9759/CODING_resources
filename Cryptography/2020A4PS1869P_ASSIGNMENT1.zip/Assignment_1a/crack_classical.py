#!/usr/bin/env python

import time

import sys

from BitVector import *


if len(sys.argv) != 3:

    sys.exit('''Needs three command-line arguments, one for '''

             '''the encrypted file and the other for the '''

             '''decrypted output file ''')


# Args check portion


# if len(sys.argv) != 3:


# sys.exit('''Needs two command-line arguments, one for '''


# '''the encrypted message file and the other for the '''


# '''decrypted output file''')


PassPhrase = "Cryptography is the art of  secret writing"


BLOCKSIZE = 64


numbytes = BLOCKSIZE // 8


# Correct

# ---------------


print("Decrypting....")


# Reduce the passphrase to a bit array of size BLOCKSIZE:

bv_iv = BitVector(bitlist=[0]*BLOCKSIZE)


for i in range(0, len(PassPhrase) // numbytes):

    textstr = PassPhrase[i*numbytes:(i+1)*numbytes]

    bv_iv ^= BitVector(textstring=textstr)


# Create a bitvector from the ciphertext hex string:

FILEIN = open(sys.argv[1])

encrypted_bv = BitVector(hexstring=FILEIN.readline().strip())


# Goes through all possible keys and performs decyrption until correct key is found

for permutation in range(2**16):

    key_bv = BitVector(intVal=permutation, size=64)

    # for i in range(0, len(key) // numbytes):

    #    keyblock = key[i*numbytes:(i+1)*numbytes]

    #    key_bv ^= BitVector(textstring=keyblock)

    # Create a bitvector for storing the decrypted plaintext bit array:

    msg_decrypted_bv = BitVector(size=0)

    len_ct = len(encrypted_bv)

    prev_block = bv_iv

    # Carry out differential XORing of bit blocks and decryption:

    for i in range(len_ct // BLOCKSIZE // 2):

        bv_read = encrypted_bv[i*BLOCKSIZE:(i+1)*BLOCKSIZE]

        bv_read ^= (key_bv ^ prev_block)

        msg_decrypted_bv += bv_read

    # Extract plaintext from the decrypted bitvector:

    output = msg_decrypted_bv.get_text_from_bitvector()

    # Checks to see if key is correct

    if "Enigma" in output:

        print(key_bv)

        print(key_bv.get_text_from_bitvector())

        # File handling, writing 'output' to the output file

        # Write plaintext to the output file:

        FILEOUT = open(sys.argv[2], 'w')

        FILEOUT.write(output)

        FILEOUT.close()

        print("Please check the file", sys.argv[2])

        print("Successfull Decryption...")

        sys.exit()
