import sys

from BitVector import *


# Args check portion

# if len(sys.argv) != 3:

# sys.exit('''Needs two command-line arguments, one for '''

# '''the encrypted message file and the other for the '''

# '''decrypted output file''')


PassPhrase = "Cryptography is the art of  secret writing"

BLOCKSIZE = 64

numbytes = BLOCKSIZE // 8


key = "bits@f463"

print("Decrypting....")


bv_iv = BitVector(bitlist=[0]*BLOCKSIZE)

for i in range(0, len(PassPhrase) // numbytes):

    textstr = PassPhrase[i*numbytes:(i+1)*numbytes]

    bv_iv ^= BitVector(textstring=textstr)


key_bv = BitVector(bitlist=[0]*BLOCKSIZE)

for i in range(0, len(key) // numbytes):

    keyblock = key[i*numbytes:(i+1)*numbytes]

    key_bv ^= BitVector(textstring=keyblock)


FILEIN = open("sample_ciphertext_p1.txt")

msg_encrypted_bv = BitVector(hexstring=FILEIN.readline().strip())

msg_decrypted_bv = BitVector(size=0)

len_ct = len(msg_encrypted_bv)

prev_block = bv_iv

for i in range(len_ct // BLOCKSIZE // 2):

    bv_read = msg_encrypted_bv[i*BLOCKSIZE:(i+1)*BLOCKSIZE]

    bv_read ^= (key_bv ^ prev_block)

    msg_decrypted_bv += bv_read

    prev_block = msg_encrypted_bv[i*BLOCKSIZE: (i+1)*BLOCKSIZE].deep_copy()


output = msg_decrypted_bv.get_text_from_bitvector()

print(output)

quit()


# File handling, writing 'output' to the output file

FILEOUT = open(sys.argv[2], 'w')

FILEOUT.write(output)

FILEOUT.close()

print("Please check the file", sys.argv[2])

print("Successfull Decryption...")
