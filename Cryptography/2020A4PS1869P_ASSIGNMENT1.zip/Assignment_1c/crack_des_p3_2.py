import itertools

import binascii

from Crypto.Cipher import DES

from Crypto.Util.number import *


# Load the sample plaintext and ciphertext

with open('sample_plaintext_p3.txt', 'rb') as f:

    sample_plaintext = f.read().strip()

with open('sample_ciphertext_p3.txt', 'rb') as f:

    sample_ciphertext = f.read().strip()


# Convert the sample plaintext and ciphertext to binary format

sample_plaintext_binary = binascii.hexlify(sample_plaintext.decode())

sample_ciphertext_binary = binascii.hexlify(bytes.fromhex(sample_ciphertext))


# Brute force the password

possible_characters = [chr(i) for i in range(32, 127)]

# generate all possible 7-lettered password combination with replacement

possible_passwords = itertools.product(possible_characters, repeat=7)


for possible_password in possible_passwords:

    # Append 'a' to the 7-character password to form the actual password

    password = ''.join(possible_password) + 'a'

    # Convert password to binary format

    password_binary = ''.join(format(ord(c), '08b') for c in password)

    # Derive the key from the password using password permutation and subkey generation

    # Calculate parity bits

    key = ""

    for i, bit in enumerate(binary_key):

        key += bit

        if (i + 1) % 7 == 0:

            num_ones = key.count("1")

            if num_ones % 2 == 0:

                key += "1"

            else:

                key += "0"

    # Remove every 8th bit to get 56-bit key

    key = "".join([key[i] for i in range(len(key)) if (i + 1) % 8 != 0])

    # Convert binary key to bytes

    key_bytes = binascii.unhexlify(hex(int(key, 2))[2:].zfill(16))

    # print("56-bit key: ", key)

    # print("Key bytes: ", key_bytes)

    # Initialize the DES cipher with the derived key

    cipher = DES.new(key, DES.MODE_ECB)

    # Encrypt the sample plaintext using the cipher

    ciphertext_attempt_binary = cipher.encrypt(sample_plaintext_binary)

    # Check if the ciphertext attempt matches the expected ciphertext

    if ciphertext_attempt_binary == sample_ciphertext_binary:

        print("Password found: ", password)

        break
